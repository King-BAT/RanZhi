import requests

baiduurl = "http://www.baidu.com/"
r = requests.get(baiduurl)
print(r)
